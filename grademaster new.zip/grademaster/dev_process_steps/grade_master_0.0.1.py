# What we have done: we have formulated a very rough pseudocode outline

# read in the CSV file with the raw data of grades 
# parse and process the raw data, put it into a useful data structure
# perform statistics, analysis, projections

# NOTE: I'm only doing the version number to the source file name to demonstrate the progression of the code development 
# (i.e., I take snapshots during the development, but in real-life, we'd just work on one source version).
