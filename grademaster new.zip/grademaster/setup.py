#!/usr/bin/env python
"""
Created on 2015-03-05
@author: j.hachmann
"""

# TODO: adapt from PyQuante

# from setuptools import setup, find_packages

# setup(name='CheML',
#       version='0.0.1',
#       author='Johannes Hachmann',
#       author_email='hachmann@buffalo.edu',
#       url='http://hachmannlab.cbe.buffalo.edu',
# #       download_url='http://www.my_program.org/files/',
#       description='CheML - A Machine Learning and Data Mining Program Suite for the Chemical Sciences',
#       long_description='CheML - A Machine Learning and Data Mining Program Suite for the Chemical Sciences',
# 
#       packages = find_packages(),
#       include_package_data = True,
#       package_data = {
#         '': ['*.txt', '*.rst'],
#         'CheML': ['data/*.html', 'data/*.css'],
#       },
#       exclude_package_data = { '': ['README'] },
#       
#       scripts = ['bin/cheml'],
#       
#       keywords='python tools utils internet www',
#       license='BSD',
#       classifiers=['Development Status :: 1 - Development',
#                    'Natural Language :: English',
#                    'Operating System :: OS Independent',
#                    'Programming Language :: Python :: 2',
#                    'License :: OSI Approved :: BSD License',
#                    'Topic :: Internet',
#                    'Topic :: Internet :: WWW/HTTP',
#                   ],
#                   
#       #setup_requires = ['python-stdeb', 'fakeroot', 'python-all'],
#       install_requires = ['setuptools'],
#      )
